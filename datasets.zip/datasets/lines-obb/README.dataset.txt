# latina > 2024-05-14 10:19pm
https://universe.roboflow.com/latina/latina

Provided by a Roboflow user
License: CC BY 4.0

